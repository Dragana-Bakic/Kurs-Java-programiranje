package utorak_20_septembar;

public class Zadatakdrugi {

	/*
	 * Da li sledeće reči mogu biti identifikatori ili ne? a)x&y b)$vr1 c)masa
	 * d)kol. e)x_1_ f)_masa g)suma brojeva
	 */

	public static void main(String[] args) {

		boolean a = false;
		boolean b = true;
		boolean c = true;
		boolean d = false;
		boolean e = true;
		boolean f = true;
		boolean g = false;

		System.out.println("Pod a) je " + a);
		System.out.println("Pod b) je " + b);
		System.out.println("Pod c) je " + c);
		System.out.println("Pod d) je " + d);
		System.out.println("Pod e) je " + e);
		System.out.println("Pod f) je " + f);
		System.out.println("Pod g) je " + g);

	}

}
