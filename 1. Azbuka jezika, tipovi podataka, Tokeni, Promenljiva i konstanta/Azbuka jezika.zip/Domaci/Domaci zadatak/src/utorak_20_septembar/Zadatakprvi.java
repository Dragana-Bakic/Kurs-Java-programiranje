package utorak_20_septembar;

public class Zadatakprvi {

	/*
	 * Definisati konstantu MAX_VREDNOST i postaviti joj vrednost na 150.
	 */

	public static void main(String[] args) {

		final float MAX_VREDNOST = 150;
		System.out.println("MAX_VREDNOST iznosi " + MAX_VREDNOST);

	}

}
