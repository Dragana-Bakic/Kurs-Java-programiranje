package utorak_20_septembar;

public class Zadataktreci {

	/*
	 * Deklarisati celobrojnu promenljivu x i realne promenljive a,b i c tipa
	 * double. Promenljivu b inicijalizovati sa 3,45, a c sa 56,78.
	 */

	public static void main(String[] args) {

		byte x;
		double a, b, c;
		b = 3.45;
		c = 56.78;

	}

}
