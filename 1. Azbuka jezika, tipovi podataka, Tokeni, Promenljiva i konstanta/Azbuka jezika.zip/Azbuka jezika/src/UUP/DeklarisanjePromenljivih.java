package UUP;

public class DeklarisanjePromenljivih {

	public static void main(String[] args) {

		// primitivni tipovi

		byte a, b = 1; // a se ne inicijalizuje, a b se inicijalizuje na 1
		int c, d; // ovde se ništa ne inicijalizuje
		boolean leto = false;

	}
}
