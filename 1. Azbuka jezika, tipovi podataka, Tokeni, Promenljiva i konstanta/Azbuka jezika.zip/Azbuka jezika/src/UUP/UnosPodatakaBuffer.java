package UUP;

import java.io.*;

public class UnosPodatakaBuffer {

	public static void main(String[] args) throws Exception {

		double x;

		// Unos podataka

		BufferedReader ulaz = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Unesite vrednost za x: ");
		x = Double.parseDouble(ulaz.readLine());

	}

}
