package UUP;

public class Komentar {
	
	// ispisivanje poruke na ekran

	/* Program napisan u programskom jeziku Java za ilustraciju komentara */

	public static void main(String[] args) {

		// Prikazuje se string "Java programski jezik"

		System.out.println("Java programski jezik");
	}
}
