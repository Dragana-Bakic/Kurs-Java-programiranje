package UUP;

public class Konstanta {

	public static void main(String[] args) {

		final double X = 3.5;
		System.out.println("Vrednost za x je " + X);

		// x = 4.8; // generisaće grešku
	}

}
