package UUP;

public class ObimKruga {

	public static void main(String[] args) {

		final double PI = 3.14159;
		double r = 5, obim;
		obim = 2 * r * PI;
		System.out.println("Obim kruga je " + obim + " za poluprečnik " + r);
	}

}
