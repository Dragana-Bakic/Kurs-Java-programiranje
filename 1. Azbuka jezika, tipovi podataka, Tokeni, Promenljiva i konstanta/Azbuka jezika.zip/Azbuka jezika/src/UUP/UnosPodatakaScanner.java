package UUP;

import java.util.Scanner;

public class UnosPodatakaScanner {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		boolean booleanValue = scanner.nextBoolean();
		String stringValue = scanner.next();
		byte byteValue = scanner.nextByte();
		int intValue = scanner.nextInt();
		short shortValue = scanner.nextShort();
		long longValue = scanner.nextLong();
		float floatValue = scanner.nextFloat();
		double doubleValue = scanner.nextDouble();

	}

}
