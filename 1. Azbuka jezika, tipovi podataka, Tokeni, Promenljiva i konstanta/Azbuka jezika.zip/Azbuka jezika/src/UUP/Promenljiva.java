package UUP;

public class Promenljiva {

	public static void main(String[] args) {

		/* Dodela jedne vrednosti većem broju promenljivih */

		int x, y, z;
		x = y = z = 150;
		System.out.println(x + y + z);
	}

}
