package UUP;

public class EksplicitnaKonverzija {

	public static void main(String[] args) {

		double d = 10.82;
		int i = (int) d;
		System.out.println("d " + d);
		System.out.println("i " + i);

	}

}
