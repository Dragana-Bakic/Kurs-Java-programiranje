package UUP;

public class ImplicitnaKonverzija {

	public static void main(String[] args) {

		int i = 10;
		double d = i;
		System.out.println("i " + i);
		System.out.println("d " + d);

	}

}
