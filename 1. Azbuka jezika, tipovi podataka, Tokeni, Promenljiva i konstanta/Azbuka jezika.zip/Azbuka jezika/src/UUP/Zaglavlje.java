package UUP;

public class Zaglavlje {

	public static void main(String[] args) {

		// Program za štampanje

		System.out.print("\tR.br.\tX\tY\tZ\n");
		System.out.println("\t1.\t2.5\t3.6\t4.9");
	}

}
