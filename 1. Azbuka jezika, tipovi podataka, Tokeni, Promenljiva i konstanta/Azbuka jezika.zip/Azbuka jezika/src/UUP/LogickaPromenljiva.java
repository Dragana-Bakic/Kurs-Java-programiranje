package UUP;

public class LogickaPromenljiva {

	public static void main(String[] args) {

		boolean tacno = true;
		boolean netacno = false;
		System.out.println("Odgovor na prvo pitanje je: " + tacno);
		System.out.println(netacno);

	}

}
