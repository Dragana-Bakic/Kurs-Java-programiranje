package UUP;

public class Promenljiva1 {

	public static void main(String[] args) {

		float f1 = 35e3f;
		double d1 = 12E4d;
		System.out.println(f1);
		System.out.println(d1);

	}

}
