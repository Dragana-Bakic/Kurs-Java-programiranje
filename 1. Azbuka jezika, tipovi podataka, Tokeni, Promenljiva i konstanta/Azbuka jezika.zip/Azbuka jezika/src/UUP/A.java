package UUP;

public class A {

	// Tipovi promenljiva

	int data = 50; // promenljiva instance
	static int m = 100; // static promenljiva

	void metod() {
		int n = 90; // lokalna promenljiva
	}

}
