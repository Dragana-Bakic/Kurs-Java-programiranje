package UUP;

public class CelobrojnaPromenljiva {

	public static void main(String[] args) {

		byte b = 120;
		short s = 5200;
		int i = 100200;
		long l = 18000000000L;
		
		System.out.println("Byte " + b);
		System.out.println("Short " + s);
		System.out.println("Int " + i);
		System.out.println("Long " + l);

	}

}
