package UUP;

public class ZnakovnaPromenljiva {

	public static void main(String[] args) {

		char velikoSlovoC = 'C';
		char c1 = 65, c2 = 66, c3 = 67;
		System.out.println(velikoSlovoC);
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);

	}

}
